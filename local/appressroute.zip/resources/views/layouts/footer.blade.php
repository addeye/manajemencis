<?php
/**
 * Created by PhpStorm.
 * User: deyelovi
 * Date: 21/01/2017
 * Time: 7:31
 */
?>
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Manajemen CIS Version 1.0.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2017 <a target="_blank" href="http://cis-nasional.id/">PEACBromo</a>.</strong> All rights reserved.
</footer>
