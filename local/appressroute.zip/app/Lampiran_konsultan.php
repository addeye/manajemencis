<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lampiran_konsultan extends Model
{
    //
}
