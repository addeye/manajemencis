<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tingkats extends Model
{
    protected $table = 'tingkats';

    protected $fillable = ['name'];
}
