<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PendidikansController extends Controller
{
    //
}
