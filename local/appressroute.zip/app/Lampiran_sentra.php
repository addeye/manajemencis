<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lampiran_sentra extends Model
{
    //
}
