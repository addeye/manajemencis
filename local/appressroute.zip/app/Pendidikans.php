<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pendidikans extends Model
{
    protected $table = 'pendidikans';

    protected $fillable = ['name'];
}
